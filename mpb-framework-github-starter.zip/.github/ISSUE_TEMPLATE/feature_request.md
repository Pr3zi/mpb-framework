---
name: Feature request
about: Suggest an idea or improvement
title: "[Feat] "
labels: enhancement
assignees: ""
---

**Problem**
What problem are you trying to solve?

**Proposal**
Describe the improvement, and where it fits (Mind/Paper/Building).

**Alternatives**
Any alternative solutions you considered.

**Additional context**
Screenshots, links, or examples.
