# Code of Conduct

To foster an open and welcoming environment, we as contributors and maintainers pledge to make participation in this project a harassment-free experience for everyone.

- Be respectful and constructive.
- Assume good intent and seek to understand.
- No harassment, discrimination, or personal attacks.

If you experience or witness unacceptable behavior, please open a confidential issue or contact the maintainers.

This project follows the spirit of the Contributor Covenant.
