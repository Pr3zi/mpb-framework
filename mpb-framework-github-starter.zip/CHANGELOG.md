# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2025-08-12
- Initial public release: MPB framework, mental model library, starter macros, and examples.
