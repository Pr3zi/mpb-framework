## Summary
What does this PR change?

## Motivation
Why is this change needed?

## Changes
- [ ] Docs
- [ ] Examples
- [ ] Prompts
- [ ] Library
- [ ] Framework

## Checklist
- [ ] Follows MPB structure (Mind → Paper → Building)
- [ ] Clear, actionable instructions
- [ ] No duplicated content across files
